=== Marvel Movie Selector ===
Contributors: Anumit Jooloor
Donate link: https://www.buymeacoffee.com/anumit
Tags: marvel, admin
Requires at least: 4.3
Tested up to: 6.4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin suggests a random Marvel movie to watch. No more confusion. No more guessing.

== Description ==

This plugin suggests a random Marvel movie to watch. No more confusion. No more guessing.
*   Complete random list of Marvel MCU movies



== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload [`Marvel Movie Selector`](https://github.com/anumit-web/marvel_movie_selector/blob/main/marvel_movie_selector.zip) to the `/wp-content/plugins/` directory

2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==
= Is this a cool plugin? =
Yes

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.0 =
* First release
